<?php
//Параметры БД
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bshopdb');

//Корневой каталог
define('APPROOT', dirname(dirname(__FILE__)));
//Корневой URL
define('URLROOT', 'http://localhost/BuildShop');
//Имя сайта
define('SITENAME', 'BuildShop');
// Версия
define('APPVERSION', '1.0.0');