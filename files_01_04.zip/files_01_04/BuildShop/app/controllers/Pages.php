<?php
class Pages extends Controller {
   public function __construct() { 
      $this->productModel = $this->model('Product');               
   }

public function index(){   //  каталог и поиск в каталоге  
   $data = [];
   $products = null;      
   if(isset($_POST["search"]))
   { 
       $param = trim($_POST["fsearch"]);
       $products = $this->productModel->getProducts($param); 
   }  
   else
   {
       $products = $this->productModel->getProducts(null);        
   }    
   $categories =  $this->productModel->getCategories();
   $data = [
       'products' => $products,
       'categories'  => $categories   
   ];
   $this->view('pages/index', $data);
}

public function show($id) { //  выборка товаров по категории
    $products = $this->productModel->getProductsForCategory($id); 
    $categories =  $this->productModel->getCategories();
   $data = [
       'products' => $products,
       'categories'  => $categories   
   ];
   $this->view('pages/index', $data);
}


}