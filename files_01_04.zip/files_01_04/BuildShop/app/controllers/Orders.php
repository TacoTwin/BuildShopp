<?php
class Orders extends Controller {
   public function __construct() { 
    $this->orderModel = $this->model('Order');  
    $this->shopModel = $this->model('Shop');   
    $this->clientModel = $this->model('Client'); 
    $this->cartModel = $this->model('Cart'); 
   }

public function index($id) {  //  загрузка страницы с созданием заявки из корзины
    // Получить записи
    $data = [];
    $orders = null;      
    if(isset($_POST["search"]))
    { 
        $param = trim($_POST["fsearch"]);
        $orders = $this->orderModel->getOrders($param, $id); 
        $shops = $this->shopModel->getShops($param); 
    }  
    else
    {
        $orders = $this->orderModel->getOrders(null, $id);
        $shops = $this->shopModel->getShops(null);         
    }    
    $data = [
        'orders' => $orders,
        'shops'   => $shops,          
    ];
    $this->view('orders/index', $data);
}

public function add() {  //  сохранение заявки в бд
    if($_SERVER['REQUEST_METHOD'] == 'POST') {            
// Санитизация данных (удаление недопустимых символов, sql-инъекций)
$_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
$clid = $this->clientModel->getClientByUserId($_SESSION['user_id']);
$total = $this->cartModel->getTotalForClientId($clid->clientId);
//var_dump($_POST['shop']);
$data = [    
    'crdate' => date('Y-m-d H:i:s'),
    'cldate' => date('Y-m-d', strtotime(date('Y-m-d H:i:s'). ' + 3 days')),
    'clientid' => $clid->clientId,
    'total' => $total->total,
    'comment' => trim($_POST['comment']),
    'shop_id' => $_POST['shop'],
    'status' => 'Создан',
    //'address'  => NULL,
    'inst'  => 0
            ];

    if(!empty(trim($_POST['address']))) {
        $data['address'] = trim($_POST['address']);
        $data['shop_id'] = NULL;
    }
    if(isset($_POST['mon'])) {
        $data['inst'] = 1;
    }

//Проверки пройдены
if($this->orderModel->addOrder($data))
{
flash('post_message', 'Запись добавлена.');
redirect('orders/success');
}
else
{
die('Ошибка.'); 
}
            
}        
}

public function success() { //  страница с сообщением о создании заявки
    $data = [];
    $this->view('orders/success', $data);
}

public function info($id) { //  товары из заявки
    $order = $this->orderModel->getOrderById($id) ;
    $prods = $this->orderModel->getOrderProds($order->id) ;
    $data = [
        'order' => $order,
        'prods' => $prods
    ];
    if($_SESSION['user_role'] == 'admin') {
        $this->view('admins/order_info', $data);
    }
    else {
        $this->view('orders/order_info', $data);
    }  
}

}