<?php
class Users extends Controller {
    public function __construct(){
$this->userModel = $this->model('User');
    }  
    
     // регистрация пользователя
     public function register(){
        // Проверка метода отправки данных (должен быть POST)
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Санитизация
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            $role='user';
           
            //Загрузка данных из формы
            $data = [
                'name' => trim($_POST['name']),
                'email' => trim($_POST['email']),
                'password' =>trim($_POST['password']),
                'confirm_password' => trim($_POST['confirm_password']),
                'role' => $role,                
                'name_err' => '',
                'email_err' => '',
                'password_err' => '',                
                'confirm_password_err' => ''
            ];
           
            //Валидация почты
            if(empty($data['email']))
            {
                $data['email_err'] = 'Укажите электронный адрес.';
            }
            else 
            {
                // Поиск почты в БД
                if($this->userModel->findUserByEmail($data['email']))
                {
                    $data['email_err'] = 'Пользователь с указанным адресом уже существует.';
                }
            }

            //Валидация имени
            if(empty($data['name']))
            {
                $data['name_err'] = 'Укажите имя.';
            }

            //Валидация пароля
            if(empty($data['password']))
            {
                $data['password_err'] = 'Введите пароль.';
            }
            elseif(strlen($data['password']) < 6)
            {
                $data['password_err'] = 'Длина пароля не менее 6 символов.';
            }

            //Валидация для повторного пароля
            if(empty($data['confirm_password']))
            {
                $data['confirm_password_err'] = 'Повторите пароль.';
            }
            else
            {
                if($data['password'] != ($data['confirm_password']))
                {
                    $data['confirm_password_err'] = 'Пароли не совпадают.';
                }            
            }

            // Проверка отсутсвия ошибок
            if(empty($data['email_err']) && empty($data['name_err']) && empty($data['password_err']) && empty($data['confirm_password_err']))
            {
//Вычисление хеш-значения для пароля
$data['password']= password_hash($data['password'], PASSWORD_DEFAULT);
            
//Регистрация пользователя
if($this->userModel->register($data))
{
    
    
    if(isset($_SESSION['user_role']))
    {
        if($_SESSION['user_role'] == "admin")
        {
            flash('message', 'Пользователь добавлен.');
            //Переход к форме авторизации
            redirect('admins/users');
        }
    }
    else {
        flash('message', 'Поздравляем! Вы зарегистрированы. Используйте форму ниже для авторизации.');
        // Переход к форме авторизации
        redirect('users/login');
    }
}
else {
    die('Ошибка!');
}
}
            else
            {
                //Загрузка представления сошибками
                $this->view('users/register', $data);
            }
        }
        else {
            // Загрузка данных из формы
           $data = [
               'name' => '',
               'email' => '',
               'password' =>'',
               'confirm_password' => '',
               'role' => '',
               'name_err' => '',               
               'email_err' => '',
               'password_err' => '',
               'confirm_password_err' => ''
           ];           
           // Загрузка представления
           $this->view('users/register', $data);
                }
    }
    
    public function login(){
        // Проверка метода отправки данных из формы
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            
             // Санитизация
             $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
        // Получение данных
        $data = [             
            'email' => trim($_POST['email']),
            'password' =>trim($_POST['password']),           
            'email_err' => '',
            'password_err' => ''            
        ];
       
        //Валидация почты
        if(empty($data['email']))
        {
            $data['email_err'] = 'Укажите логин';
        }      

        //Валидация пароля
        if(empty($data['password']))
        {
            $data['password_err'] = 'Укажите пароль';
        }       

        // проверка адреса
        if($this->userModel->findUserByEmail($data['email']))
        {
            
        }        
        else
        {
            // Пользователь не найден
            $data['email_err'] = 'Пользователь не существует';
        }
        
        // Проверка на отсутсвие ошибок
        if(empty($data['email_err']) && empty($data['password_err']))
        {

// Создание сессии для пользователя
$loggedInUser = $this->userModel->login($data['email'], $data['password']);
if($loggedInUser)
{
    
$this->createUserSession($loggedInUser);
}
else
{
    $data['password_err'] = 'Пароль не верен.';
    $this->view('users/login', $data);
}
        }
        else
        {            
            $this->view('users/login', $data);
        }
    
    }
        else {           
           $data = [               
               'email' => '',
               'password' =>'',                                    
               'email_err' => '',               
               'password_err' => ''               
           ];  
          
           $this->view('users/login', $data);
                }
    }
    public function createUserSession($loggedInUser)
    {
        $_SESSION['user_id'] = $loggedInUser->id;
        $_SESSION['user_name'] = $loggedInUser->user_name; 
        $_SESSION['user_email'] = $loggedInUser->email;
        $_SESSION['user_role'] = $loggedInUser->role;             
        if($_SESSION['user_role'] == "admin") redirect('admins/index'); 
        if($_SESSION['user_role'] == "user")  redirect('pages/index'); 
    }

    public function logout()
    {
        unset($_SESSION['user_id']) ;
        unset($_SESSION['user_name']) ; 
        unset($_SESSION['user_email']) ;
        unset($_SESSION['user_role']); 
        session_destroy();
        redirect('users/login');
    } 
}