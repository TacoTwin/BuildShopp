<?php
class Admins extends Controller {
   public function __construct() { 
    $this->cartModel = $this->model('Cart');   
    $this->clientModel = $this->model('Client'); 
    $this->productModel = $this->model('Product'); 
    $this->userModel = $this->model('User');  
    $this->orderModel = $this->model('Order');   
   }

   public function index() { // загрузка стартового окна лк админа
    $data = [  ];
    $this->view('admins/index', $data);
   }

   public function categories() { //  загрузка таблицы с категориями
    $categories = $this->productModel->getCategories();
    $data = [
        'categories' => $categories
      ];
    $this->view('admins/categories', $data);
   }

   public function products() { //  загрузка таблицы с товарами
    $products = $this->productModel->getProductsAndCategories();
    $data = [
        'products' => $products
      ];
    $this->view('admins/products', $data);
   }

   public function clients() { //  загрузка таблицы с клиентами и админами
    $clients = $this->clientModel->getClientsAndUsers();
    $admins = $this->userModel->getAdmins();
    $data = [
        'clients' => $clients,
        'admins' => $admins
      ];
    $this->view('admins/clients', $data);
   }

   public function orders() { //  загрузка таблицы с заявками
    $orders = $this->orderModel->getAllOrders();
    $data = [
        'orders' => $orders
      ];
    $this->view('admins/orders', $data);
   }

   public function addcategory() { //  обработка добавления категории
    if($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            
// Санитизация данных (удаление недопустимых символов, sql-инъекций)
$_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
$data = [
    'title' => trim($_POST['title']),    
    'title_err' =>''     
            ];

            // Валидация 
            if(empty($data['title']))
            {
                $data['title_err'] = 'Укажите название.';
            }  
            // Проверка отсутствия ошибок
            if(empty($data['title_err']))
            {
//Проверки пройдены
if($this->productModel->addCategory($data))
{
flash('post_message', 'Категория добавлена.');
redirect('admins/categories');
}
else
{
die('Ошибка.'); 
}
            }
            else
            {
                // Загружаем представление с сообщениями об ошибках
                $this->view('admins/addcategory', $data);
            }
}
        else
        {
        $data = [
            'title' => '',            
            'title_err' => ''            
        ];
        $this->view('admins/addcategory', $data);
    }    
   }

   public function editCategory($id)  { //  обработка редактирования категории
       if($_SERVER['REQUEST_METHOD'] == 'POST')  {           
// Санитизация
$_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
$data = [
   'id' => $id, 
   'title' => trim($_POST['title']),   
   'title_err' =>''    
           ];

           // Валидация 
           if(empty($data['title']))  {
               $data['title_err'] = 'Укажите название.';
           }  
           // Проверка отсутствия ошибок
           if(empty($data['title_err']))  {
//Проверки пройдены
if($this->productModel->editCategory($data))  {
flash('post_message', 'Категория изменена.');
redirect('admins/categories');
}
else {
die('Ошибка');
}
           }
           else           {
               // Загружаем представление с сообщениями об ошибках
               $this->view('admins/editCategory', $data);
           }
}
       else       {     
           // Получение объекта-сообщения из модели
           $cat = $this->productModel->getCategoryById($id);       
       $data = [           
               'id' => $id,
               'title' => $cat->title,               
               'title_err' =>''                           
       ]; 
       $this->view('admins/editCategory', $data);
   }    
   } 

   public function deletecategory($id) { //  обработка удаления категории
     // выполнение
     if($cat = $this->productModel->removeCat($id)) {                
        flash('post_message', 'Категория удалена.');       
     }
     else {         
        flash('post_message', 'Удаление категории невозможно.');        
     }
     $categories = $this->productModel->getCategories();
     $data = [
        'categories' => $categories
      ]; 
      redirect('admins/categories', $data);     
   }

   public function addproduct() { //  обработка добавления товара
    if($_SERVER['REQUEST_METHOD'] == 'POST')     {        
// Санитизация данных (удаление недопустимых символов, sql-инъекций)
$_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
$categories = $this->productModel->getCategories();
$data = [
'categories' => $categories,
'title' => trim($_POST['title']),
'price' => trim($_POST['price']),
'minidescription' => trim($_POST['minidescription']),
'description' => trim($_POST['description']),
'image' => $_FILES["image"]["name"],
'cat' => trim($_POST['cat']), 
'title_err' =>'' ,  
'price_err' =>'' ,
'minidescription_err' =>'' ,   
'description_err' =>'' ,  
'image_err' =>''     
        ];
        // Валидация 
        if(empty($data['title']))    {
            $data['title_err'] = 'Укажите название.';
        } 
        if(empty($data['minidescription']))    {
            $data['minidescription_err'] = 'Укажите описание.';
        }  
        if(empty($data['description']))    {
            $data['description_err'] = 'Укажите описание.';
        } 
        if(empty($data['price']))    {
            $data['price_err'] = 'Укажите цену.';
        } 
        if(empty($data['image']))    {
            $data['image_err'] = 'Выберите фото.';
        }  
        // Проверка отсутствия ошибок
        if(empty($data['title_err']) && empty($data['minidescription_err']) && empty($data['description_err']) && empty($data['price_err']) && empty($data['image_err']))
        {
//Проверки пройдены
if($this->productModel->addProduct($data)) {
flash('post_message', 'Товар добавлен.');
redirect('admins/products');
}
else {
die('Ошибка.'); 
}
        }
        else {
            // Загружаем представление с сообщениями об ошибках
            $this->view('admins/addproduct', $data);
        }
}
    else
    {
        $categories = $this->productModel->getCategories();
    $data = [
        'categories' => $categories,
        'title' => '',
'price' => '',
'minidescription' => '',
'description' => '',
'image' => '',
'cat' => '', 
'title_err' =>'' ,  
'price_err' =>'' ,
'minidescription_err' =>'' ,   
'description_err' =>'' ,  
'image_err' =>''             
    ];
    $this->view('admins/addproduct', $data);
}    
   }

   public function editproduct($id) { //  обработка редактирования товара
    if($_SERVER['REQUEST_METHOD'] == 'POST') {              
// Санитизация данных (удаление недопустимых символов, sql-инъекций)
$_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
$data = [ 
    'id' => $id,
    'title' => trim($_POST['title']),
    'price' => trim($_POST['price']),
    'minidescription' => trim($_POST['minidescription']),
    'description' => trim($_POST['description']),
    'image' => $_FILES["image"]["name"],
    'cat' => trim($_POST['cat']), 
    'title_err' =>'' ,  
    'price_err' =>'' ,
    'minidescription_err' =>'' ,   
    'description_err' =>''          
            ];
            // Валидация 
            if(empty($data['title']))    {
                $data['title_err'] = 'Укажите название.';
            } 
            if(empty($data['minidescription']))    {
                $data['minidescription_err'] = 'Укажите описание.';
            }  
            if(empty($data['description']))    {
                $data['description_err'] = 'Укажите описание.';
            } 
            if(empty($data['price']))    {
                $data['price_err'] = 'Укажите цену.';
            } 
            
            if(empty($data['title_err']) && empty($data['minidescription_err']) && empty($data['description_err']) && empty($data['price_err'])) {
 //Проверки пройдены
if($this->productModel->editProduct($data)) {
    flash('post_message', 'Запись о товаре изменена.');
    redirect('admins/products');
    }
    else {
    die('Ошибка.'); 
    }
            }
            else {
                // Загружаем представление с сообщениями об ошибках
                $this->view('admins/editproduct', $data);
            }
                }
        else
        {
            $categories = $this->productModel->getCategories();
            $product = $this->productModel->getProductById($id); 
        $data = [
            'id' => $id,
            'categories' => $categories,
            'title' => $product->title,
    'price' => $product->price,
    'minidescription' => $product->minidescription,
    'description' => $product->description,
    'image' => $product->image,
    'cat' => $product->cat_id, 
    'title_err' =>'' ,  
    'price_err' =>'' ,
    'minidescription_err' =>'' ,   
    'description_err' =>''                
        ];
        $this->view('admins/editproduct', $data);
    }   
}

public function deleteproduct($id) { //  обработка удаления товара
// выполнение
if($prod = $this->productModel->removeProduct($id)) {                
    flash('post_message', 'Товар удален.');       
 }
 else {         
    flash('post_message', 'Удаление товара невозможно.');        
 }
 $products = $this->productModel->getProductsAndCategories();
    $data = [
        'products' => $products
      ];
    $this->view('admins/products', $data); 
}

public function addadmin() { //  обработка добавления админа
    if($_SERVER['REQUEST_METHOD'] == 'POST')     {        
        // Санитизация данных (удаление недопустимых символов, sql-инъекций)
        $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
        $data = [
        'name' => trim($_POST['name']),
        'email' => trim($_POST['email']),
        'password' => trim($_POST['password']) ,
        'role' => 'admin',
        'email_err'  => '' ,
        'password_err'  => ''    
                ]; 
                if($this->userModel->findUserByEmail($data['email']))
                {
                    $data['email_err'] = 'Пользователь с указанным адресом уже существует.';
                }
                if(strlen($data['password']) < 6)
                {
                $data['password_err'] = 'Длина пароля не менее 6 символов.';
                }
                // Проверка отсутствия ошибок
                if(empty($data['email_err']) && empty($data['password_err'])) {
        //Проверки пройдены
        if($this->userModel->register($data)) { 
        flash('post_message', 'Администратор добавлен.');
        redirect('admins/clients');
        }
        else {
        die('Ошибка.'); 
        }
                }
                else {
                    // Загружаем представление с сообщениями об ошибках
                    $this->view('admins/addadmin', $data);
                }
        }
            else {                
            $data = [
                'name' => '',
                'email' => '',
                'password' => '' ,
                'role' => 'admin',
                'email_err'  => '' ,
                'password_err'  => ''          
            ]; 
            $this->view('admins/addadmin', $data);
        }     
}

public function editadmin($id) { //  обработка редактирования админа
    if($_SERVER['REQUEST_METHOD'] == 'POST')     {        
        // Санитизация данных (удаление недопустимых символов, sql-инъекций)
        $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
        $data = [
            'id' => $id,
        'name' => trim($_POST['name']),
        'email' => trim($_POST['email']),
        'password' => trim($_POST['password']) ,
        'role' => 'admin',
        'email_err'  => '' ,
        'password_err'  => ''    
                ];                
                if(!empty($data['password'])) {
                    if(strlen($data['password']) < 6) {
                        $data['password_err'] = 'Длина пароля не менее 6 символов.';
                        }
                }                
                // Проверка отсутствия ошибок
                if(empty($data['email_err']) && empty($data['password_err'])) {
        //Проверки пройдены
        if($this->userModel->editadmin($data)) { 
        flash('post_message', 'Запись об администраторе изменена.');
        redirect('admins/clients');
        }
        else {
        die('Ошибка.'); 
        }
                }
                else {
                    // Загружаем представление с сообщениями об ошибках
                    $this->view('admins/editadmin', $data);
                }
        }
            else {     
                $admin  = $this->userModel->getUserById($id);         
            $data = [
                'id' => $id,
                'name' => $admin->user_name,
                'email' => $admin->email,
                'password' => '',
                'role' => 'admin',
                'email_err'  => '' ,
                'password_err'  => ''          
            ]; 
            $this->view('admins/editadmin', $data);
        }     
}

public function deladmin($id) { //  обработка удаления админа
    // выполнение
if($prod = $this->userModel->removeUser($id)) {                
    flash('post_message', 'Администратор удален.');       
 }
 else {         
    flash('post_message', 'Удаление пользователя невозможно.');        
 }
 $clients = $this->clientModel->getClientsAndUsers();
    $admins = $this->userModel->getAdmins();
    $data = [
        'clients' => $clients,
        'admins' => $admins
      ];
    $this->view('admins/clients', $data); 
}

public function addclient() { //  обработка добавления клиента
    if($_SERVER['REQUEST_METHOD'] == 'POST')     {        
        // Санитизация данных (удаление недопустимых символов, sql-инъекций)
        $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
        $_POST['confirm_password'] = $_POST['password'];
        $data = [        
        'name' => trim($_POST['name']),
        'email' => trim($_POST['email']),
        'password' => trim($_POST['password']) ,
        'confirm_password' => trim($_POST['password']) , 
        'role' => 'user',
        'email_err'  => '' ,
        'password_err'  => ''    
                ];  
                if($this->userModel->findUserByEmail($data['email']))
                {
                    $data['email_err'] = 'Пользователь с указанным адресом уже существует.';
                } 
                    if(strlen($data['password']) < 6) {
                        $data['password_err'] = 'Длина пароля не менее 6 символов.';
                        }
                              
                // Проверка отсутствия ошибок
                if(empty($data['email_err']) && empty($data['password_err'])) {
        //Проверки пройдены
        if($this->userModel->addclient($data)) { 
        flash('post_message', 'Запись добавлена.');
        redirect('admins/clients');
        }
        else {
        die('Ошибка.'); 
        }
                }
                else {
                    // Загружаем представление с сообщениями об ошибках
                    $this->view('admins/addclient', $data);
                }
        }
            else {    
                       
            $data = [               
                'name' => '',
                'email' => '',
                'password' => '',
                'confirm_password' => '', 
                'role' => 'user',
                'email_err'  => '' ,
                'password_err'  => ''          
            ]; 
            $this->view('admins/addclient', $data);
        }     
}

public function delclient($id) { //  обработка удаления клиента
     $client = $this->clientModel->getClientById($id);    
     if($this->clientModel->removeClient($id)) {             
       
    if($this->userModel->removeUser($client->user_id)) {
        flash('post_message', 'Пользователь удален.'); 
    }
 }
 else {         
    flash('post_message', 'Удаление пользователя невозможно.');        
 }
 $clients = $this->clientModel->getClientsAndUsers();
    $admins = $this->userModel->getAdmins();
    $data = [
        'clients' => $clients,
        'admins' => $admins
      ];
    $this->view('admins/clients', $data); 
}

public function editorder($id) { //  обработка редактирования заявки
    if($_SERVER['REQUEST_METHOD'] == 'POST')     {        
        // Санитизация данных (удаление недопустимых символов, sql-инъекций)
        $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
        $data = [
        'id' => $id,
        'cldate' => trim($_POST['cldate']),
        'status' => trim($_POST['status'])  
                ]; 
        //Проверки пройдены
        if($this->orderModel->editorder($data)) { 
        flash('post_message', 'Запись о заявке изменена.');
        redirect('admins/orders');
        }
        else {
        die('Ошибка.'); 
        }               
        }
            else {     
                $order  = $this->orderModel->getOrderById($id);         
            $data = [
                'id' => $id,
                'crdate' => $order->crdate,
                'cldate' => $order->cldate,
                'status' => $order->status                         
            ]; 
            $this->view('admins/editorder', $data);
        } 
}

public function delorder($id) { //  обработка удаления заявки
    if($this->orderModel->delOrder($id)) {
        flash('post_message', 'Заявка удалена.'); 
    }

    $orders = $this->orderModel->getAllOrders();
    $data = [
        'orders' => $orders
      ];
    $this->view('admins/orders', $data);
}
}