<?php
class Products extends Controller {
   public function __construct() { 
      $this->productModel = $this->model('Product');          
   }

public function info($id){  //  страница товара
       $product = $this->productModel->info($id); 
   $data = [
       'product' => $product     
   ];
   $this->view('pages/product-page', $data);
}
}