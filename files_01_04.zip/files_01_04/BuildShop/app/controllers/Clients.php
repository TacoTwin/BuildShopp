<?php
class Clients extends Controller
{
    public function __construct()
    {
        $this->clientModel = $this->model('Client');    
        $this->userModel = $this->model('User');     
        $this->orderModel = $this->model('Order'); 
    }

    public function index() //  загрузка личного кабинета пользователя-клиента
    {
 // Получить записи
 $client = $this->clientModel->getClientByUserId($_SESSION['user_id']);  
 $user = $this->userModel->getUserById($_SESSION['user_id']);  
 $orders = $this->orderModel->getOrdersByClientId($client->clientId);

 $data = [
     'client' => $client, 
     'user'=> $user,
     'orders' => $orders
 ];

 $this->view('clients/index', $data);
    }
    
    public function change() { //  изменение данных клиента
        // Проверка метода отправки данных (должен быть POST)
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Санитизация
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);           
            //Загрузка данных из формы

            $client = $this->clientModel->getClientByUserId($_SESSION['user_id']);  
            $user = $this->userModel->getUserById($_SESSION['user_id']);   
            $orders = $this->orderModel->getOrdersByClientId($client->clientId);
  //var_dump($client);
            $data = [
                'client' => $client,
                'user' => $user,
                'orders' => $orders,
                'lname' => trim($_POST['ln']),
                'name' => trim($_POST['n']),
                'pat' =>trim($_POST['pat']),
                'phone' => trim($_POST['ph']),
                'company' => trim($_POST['comp']),
                'user_name' => trim($_POST['lg']),
                'email' => trim($_POST['email']),   
                'password' => trim($_POST['pp']), 
                'email_err' => '',  
                'password_err' => ''               
            ];           
            
            //Валидация пароля
            if(!empty($data['password']))
            {
                if(strlen($data['password']) < 6)
                {
                    $data['password_err'] = 'Длина пароля не менее 6 символов.';
                }                
            } 
            // Проверка отсутсвия ошибок
            if(empty($data['email_err']) && empty($data['password_err']))
            {
               
//Вычисление хеш-значения для пароля
if(!empty($data['password'])) $data['password']= password_hash($data['password'], PASSWORD_DEFAULT);
            
//Регистрация пользователя
if($this->clientModel->updateClient($data)) 
{
    $client = $this->clientModel->getClientByUserId($_SESSION['user_id']);  
    $user = $this->userModel->getUserById($_SESSION['user_id']);   
    $orders = $this->orderModel->getOrdersByClientId($client->clientId);
    $data = [
        'client' => $client, 
        'user'=> $user,
        'orders' => $orders
    ];
    $this->view('clients/index', $data);
}
else {
    die('Ошибка!');
}
}
            else
            {
                //Загрузка представления сошибками
                $this->view('clients/index', $data);
            }
        }        
    }
}