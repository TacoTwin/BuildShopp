<?php
class Carts extends Controller {
   public function __construct() { 
    $this->cartModel = $this->model('Cart');   
    $this->clientModel = $this->model('Client'); 
    $this->productModel = $this->model('Product');      
   }

public function index() //  загрузка  окна корзины
{ 
    // Получить записи
    $data = [];
    $carts = null;      
    if(isset($_POST["search"]))
    { 
        $param = trim($_POST["fsearch"]);
        $carts = $this->cartModel->getCarts($param); 
    }  
    else
    {
        $carts = $this->cartModel->getCarts(null);        
    }    
    $data = [
        'carts' => $carts       
    ];
    $this->view('carts/index', $data);
}

public function minus($id) { //  обработка уменьшения кол-ва для позиции
    $cart = $this->cartModel->getCartById($id); 
    if($cart->amount > 1)  {
        $val = $cart->amount-1;
        if($this->cartModel->changeAmount($cart->cartId, $val)) {
            $carts = $this->cartModel->getCarts(null); 
            $data = [
                'carts' => $carts       
            ];
            $this->view('carts/index', $data);
        }        
    } 

    $carts = $this->cartModel->getCarts(null); 
            $data = [
                'carts' => $carts       
            ];
            $this->view('carts/index', $data);
}

public function plus($id) { //  обработка увеличения кол-ва для позиции
    $cart = $this->cartModel->getCartById($id);    
        $val = $cart->amount+1;
        if($this->cartModel->changeAmount($cart->cartId, $val)) {
            $carts = $this->cartModel->getCarts(null); 
            $data = [
                'carts' => $carts       
            ];
            $this->view('carts/index', $data);
        }   
}

public function del_product($id) { //  обработка удаления позиции
 // выполнение
 if($cart = $this->cartModel->removeCart($id))
 {
     $carts = $this->cartModel->getCarts(null);
         $data = [
             'carts' => $carts
         ];         
         redirect('carts/index', $data);
 }
 else
 {
     
 }
}

public function add($id) { //  обработка добавления товара в корзину
    if(isLoggedIn()) {
        $client = $this->clientModel->getClientByUserId($_SESSION['user_id']);  
        if($this->cartModel->addProdToCart($id, $client->clientId)) {
           $products = $this->productModel->getProducts(null);
           $categories =  $this->productModel->getCategories();
          $data = [
              'products' => $products,
              'categories'  => $categories   
          ];
          $this->view('pages/index', $data);    
        }
    }
    else {
        flash('register_success', 'Авторизируйтесь для работы с корзиной.'); 
        redirect('users/login');
    }
 
}


}