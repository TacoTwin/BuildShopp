<?php
class Cart{     
    private $db;
    public function __construct(){
        $this->db = new Database;
    }
    public function getCarts($param){ // Получить товары из корзины авторизованного клиента
        $results = null;
        if($param == null)
        {
        $this->db->query("SELECT cartId, title, amount, p.id as pid, cl.clientId as clid, p.price as price FROM carts c, clients cl, products p where c.client_id=cl.clientId and cl.user_id=".$_SESSION['user_id']." and c.product_id=p.id");
        $results = $this->db->resultSet();
        } 
        else
        {
        //$this->db->query("select DISTINCT lastname, name, patronymic, rewards, hire_date, speciality, faculty_id, title from teachers, faculties where (teachers.faculty_id=faculties.id) and (lastname like '%".$param."%' or name like '%".$param."%' or rewards like '%".$param."%')");
        //$results = $this->db->resultSet();
        }       
        return $results;
    } 

    public function getCartById($id)     { //  получить номер строки с корзиной
        $this->db->query('select * from carts where cartId = :id');
        $this->db->bind('id', $id);
        $row = $this->db->single(); 
        return $row;
    }

    public function changeAmount($id, $val) { //  изменить кол-во товара в корзине

        $this->db->query('update carts set amount = :val where cartId = :id');
     
     $this->db->bind('id', $id);
     $this->db->bind('val', $val);   
     if($this->db->execute())
     {
        return true;
     }
     else
     {
         return false;
     }
    }

    public function removeCart($pid) { //  удалить запись о корзине
        $this->db->query('delete from carts where cartId=:id');
     $this->db->bind('id', $pid);
     if($this->db->execute())
     {
         return true;
     }
     else
     {
         return false;
     }
    }

    public function getTotalForClientId($clid) { //  вычислить стоимость корзины пользователя
        $this->db->query('select sum(p.price*c.amount) as total from carts c, products p where c.product_id=p.id and client_id=:id');
        $this->db->bind('id', $clid);
        $row = $this->db->single(); 
        return $row;
    }    

    public function addProdToCart($id, $clientId) { //  добавить товар в корзину
        $this->db->query('select * from carts c where c.client_id=:cid and c.product_id=:pid');
        $this->db->bind('cid', $clientId);
        $this->db->bind('pid', $id);
        $this->db->execute();
        $count = $this->db->rowCount();        
        if($count == 0) {
            $this->db->query('INSERT INTO carts(client_id, product_id, amount) VALUES (:client_id, :product_id, :amount)');
            //привязка параметров
            $this->db->bind('client_id', $clientId);
            $this->db->bind('product_id', $id);
            $this->db->bind('amount', 1);             
        
            // выполнение
            if($this->db->execute())
            {
                return true;
            }
            else
            {
                return false;
            }
        } 
        else {
            $this->db->query('select amount from carts c where c.client_id=:cid and c.product_id=:pid');
            $this->db->bind('cid', $clientId);
            $this->db->bind('pid', $id); 
            $row = $this->db->single();
            
            $this->db->query('update carts c set amount=:amount where c.client_id=:cid and c.product_id=:pid');
            //привязка параметров
            $this->db->bind('cid', $clientId);
            $this->db->bind('pid', $id);
            $this->db->bind('amount', $row->amount+1);             
        
            // выполнение
            if($this->db->execute())
            {
                return true;
            }
            else
            {
                return false;
            }



        }       
    }
}