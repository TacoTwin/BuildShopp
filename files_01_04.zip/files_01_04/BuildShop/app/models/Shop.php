<?php
class Shop{     
    private $db;
    public function __construct(){
        $this->db = new Database;
    }
    public function getShops($param){ // Получить список пунктов выдачи
        $results = null;
        if($param == null)
        {
        $this->db->query("SELECT * from shops");
        $results = $this->db->resultSet();
        } 
        else
        {
            $this->db->query("SELECT * from shops");
        $results = $this->db->resultSet();
       
        }       
        return $results;
    } 
}