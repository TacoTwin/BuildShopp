<?php
class Order{     
    private $db;
    public function __construct(){
        $this->db = new Database;
    }
    
    public function getOrdersByClientId($id) { //  найти заявки клиента
        $this->db->query("SELECT * FROM orders o WHERE o.clientid=".$id);
        $results = $this->db->resultSet();
        return $results;
    }
    
    public function getAllOrders() { //  найти все заявки
        $this->db->query("SELECT * FROM orders o, clients c where o.clientid=c.clientId");
        $results = $this->db->resultSet();
        return $results;
    }
    
    public function getOrders($param, $id){ // найти товары из корзины по номеру клиента
        $results = null;
        if($param == null)
        {
        $this->db->query("SELECT * FROM carts c, products p where c.product_id=p.id and c.client_id=".$id);
        $results = $this->db->resultSet();
        } 
        else
        {
        //$this->db->query("select DISTINCT lastname, name, patronymic, rewards, hire_date, speciality, faculty_id, title from teachers, faculties where (teachers.faculty_id=faculties.id) and (lastname like '%".$param."%' or name like '%".$param."%' or rewards like '%".$param."%')");
        //$results = $this->db->resultSet();
        }       
        return $results;
    } 

    public function addOrder($data) { //  добавить заявку
     $this->db->query('INSERT INTO orders(crdate, cldate, clientid, total, comment, shop_id, status,  address, installation) VALUES (:crdate, :cldate, :clientid, :total, :comment, :shop_id, :status,  :address, :installation)');
     //привязка параметров
     $this->db->bind('crdate', $data['crdate']);
     $this->db->bind('cldate', $data['cldate']);
     $this->db->bind('clientid', $data['clientid']);  
     $this->db->bind('total', $data['total']);    
     $this->db->bind('comment', $data['comment']);     
     $this->db->bind('shop_id', $data['shop_id']);    
     $this->db->bind('status', $data['status']);
     $this->db->bind('address', $data['address']);    
     $this->db->bind('installation', $data['inst']);     
     // выполнение
     if($this->db->execute()) 
     {
        $oid = $this->db->lastId();        
        
        $this->db->query('SELECT * FROM carts c, products p where c.product_id=p.id and c.client_id='.$data['clientid']);        
        $products = $this->db->resultSet();
        foreach ($products as &$product) {
            $this->db->query('INSERT INTO order_products (product_id, order_id, amount) VALUES (:product_id, :order_id, :amount)');
            $this->db->bind('product_id', $product->product_id);
            $this->db->bind('order_id', $oid);
            $this->db->bind('amount', $product->amount);
            
            $this->db->execute();  
        }       
        unset($product);
$_SESSION['cldate'] = $data['cldate'];
        return true;
     }
     else
     {
         return false;
     }
    }

    public function getOrderById($id)  //  найти заявку по id
    {
        $this->db->query('select * from orders where id = :id');
        $this->db->bind('id', $id);
        $row = $this->db->single(); 
        return $row;
    }

    public function getOrderProds($id) { //  получить список товаров заявки
        $this->db->query("SELECT * FROM order_products op, products p where op.product_id=p.id and op.order_id=".$id);
        $results = $this->db->resultSet();
        return $results;
    }

    public function editorder($data) { //  изменить заявку
        $this->db->query('update orders set cldate=:cldate, status=:status where id=:id');
        //привязка параметров       
        $this->db->bind('cldate', $data['cldate']);            
        $this->db->bind('id', $data['id']);    
        $this->db->bind('status', $data['status']);
        if($this->db->execute()) {
            return true;
        }
        else {
            return false;
        }
    }

    public function delOrder($id) { //  оудалить заявку
        $this->db->query('delete from order_products where order_id=:id');
        $this->db->bind('id', $id); 
        if($this->db->execute()) {
            $this->db->query('delete from orders where id=:id'); 
            $this->db->bind('id', $id); 
            if($this->db->execute()) {
                return true;
            }
            else {
                return false;
            }
        }
    }

    
}