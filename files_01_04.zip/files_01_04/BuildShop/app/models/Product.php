<?php
class Product{     
    private $db;
    public function __construct(){
        $this->db = new Database;
    }
    public function getProducts($param){ // Получить список товаров или найти товары
        $results = null;
        if($param == null)
        {
        $this->db->query("select * from products");
        $results = $this->db->resultSet();
        } 
        else
        {
        $this->db->query("select * from products where (title like '%".$param."%' or minidescription like '%".$param."%' or description like '%".$param."%')");
        $results = $this->db->resultSet();
        }       
        return $results;
    } 

    public function info($id) { //  поиск товара по id
        $this->db->query("select * from products where id=:id");
        $this->db->bind('id', $id);
        $row = $this->db->single();        
        return $row;
    } 

    public function getCategories(){ //  список всех категорий
        $this->db->query("select * from categories");
        $results = $this->db->resultSet();
        return $results;
    }

    public function getProductsForCategory($id)  //  найти товары категории
    {
        $this->db->query('select * from products p where cat_id = :id');
        $this->db->bind('id', $id);
        $rows = $this->db->resultSet(); 
        return $rows;
    }

    public function getProductsAndCategories() { //  получить список товаров и их категорий
        $this->db->query('SELECT p.id, p.title, price, description, minidescription, image, c.title as cat FROM products p, categories c where c.id=p.cat_id');
        $rows = $this->db->resultSet(); 
        return $rows;
    }

    public function addCategory($data) { //  добавить категорию
        $this->db->query('insert into categories(title) VALUES (:title)');
        //привязка параметров
        $this->db->bind('title', $data['title']); 
        // выполнение
        if($this->db->execute())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public function editCategory($data) { //  изменить категорию
        $this->db->query('update categories set title=:title where id=:id');
        //привязка параметров
        $this->db->bind('title', $data['title']); 
        $this->db->bind('id', $data['id']);
        // выполнение
        if($this->db->execute())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public function getCategoryById($id) { //  найти категорию по id
        $this->db->query('SELECT * FROM categories WHERE id = :id');
        $this->db->bind('id', $id);
        $row = $this->db->single();        
            return $row;
    }

    public function removeCat($id) { //  удалить категорию
        $this->db->query('delete from categories where id=:id');
     $this->db->bind('id', $id);
     if($this->db->execute())  {
         return true;
     }
     else  {
         return false;
     }
    }

    public function addProduct($data) { //  добавить товар
        $this->db->query('INSERT INTO products(title, price, minidescription, image, description, cat_id) VALUES (:title, :price, :minidescription, :image, :description, :cat_id)');
        //привязка параметров
        $this->db->bind('title', $data['title']);
        $this->db->bind('price', $data['price']);
        $this->db->bind('minidescription', $data['minidescription']);  
        $this->db->bind('description', $data['description']);  
        $this->db->bind('image', $data['image']);  
        $this->db->bind('cat_id', $data['cat']);
        // выполнение
        if($this->db->execute()) {
            return true;
        }
        else {
            return false;
        }
    }

    public function getProductById($id) { //  найти товар по id
        $this->db->query('SELECT * FROM products WHERE id = :id');
        $this->db->bind('id', $id);
        $row = $this->db->single();        
            return $row;
    }

    public function editProduct($data) { //  изменить запись о товаре

        if($data['image'] != null) {
            $this->db->query('update products set title=:title, price=:price, minidescription=:minidescription, image=:image, description=:description, cat_id=:cat where id=:id');
            //привязка параметров
            $this->db->bind('id', $data['id']);
            $this->db->bind('title', $data['title']);
            $this->db->bind('price', $data['price']);
            $this->db->bind('minidescription', $data['minidescription']);  
            $this->db->bind('description', $data['description']);  
            $this->db->bind('image', $data['image']);  
            $this->db->bind('cat', $data['cat']);
        }
        else {
            $this->db->query('update products set title=:title, price=:price, minidescription=:minidescription, description=:description, cat_id=:cat where id=:id');
        //привязка параметров
        $this->db->bind('id', $data['id']);
        $this->db->bind('title', $data['title']);
        $this->db->bind('price', $data['price']);
        $this->db->bind('minidescription', $data['minidescription']);  
        $this->db->bind('description', $data['description']);           
        $this->db->bind('cat', $data['cat']);
        }        
        // выполнение
        if($this->db->execute()) {
            return true;
        }
        else {
            return false;
        }
    } 
    
    public function removeProduct($id) { // удалить товар
        $this->db->query('delete from products where id=:id');
     $this->db->bind('id', $id);
     if($this->db->execute())  {
         return true;
     }
     else  {
         return false;
     }
    }
}