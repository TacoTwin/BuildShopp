<?php
class User {
    private $db;
public function __construct(){
    $this->db = new Database;
}

//Регистрация
public function register($data){
    $this->db->query('insert into users(user_name, email, password, role) values (:name, :email, :password, :role)');
    //привязка параметров
    $this->db->bind('name', $data['name']);
    $this->db->bind('email', $data['email']);
    $this->db->bind('password', $data['password']);
    $this->db->bind('role', $data['role']);
    // Выполнение запроса
    if($this->db->execute())    {
        $u_id = $this->db->lastId(); 
        $this->db->query("INSERT INTO clients(lname, name, pat, phone, user_id, company) VALUES (' ', ' ', ' ', ' ', :user_id, ' ')");
        $this->db->bind('user_id', $u_id);
        if($this->db->execute())         {
            return true;
        } else {
            return false;
        }        
    }     else     {
        return false;
    }
}

// Авторизация пользователя
public function login($email, $password)
{
    $this->db->query('SELECT * FROM users WHERE email = :email');
    $this->db->bind(':email', $email);
    $row = $this->db->single();
    $hashed_password = $row->password;
    if(password_verify($password, $hashed_password))
    {
        return $row;
    }
    else
    {
        return false;
    }
}


//Поиск пользователя по почте
public function findUserByEmail($email) {
    $this->db->query('SELECT * FROM users WHERE email = :email');
$this->db->bind('email', $email);
$row = $this->db->single();

if($this->db->rowCount() > 0)
{
    return true;
}
else{
    return false;
}
}

// Получение данных пользователя по идентификатору
public function getUserById($id) {
    $this->db->query('SELECT * FROM users WHERE id = :id');
$this->db->bind('id', $id);
$row = $this->db->single();

    return $row;
}

public function getAdmins() {
    $this->db->query("SELECT * FROM users where role='admin'");
        $results = $this->db->resultSet();
        return $results;
}

public function editadmin($data) {
    if($data['password'] != null) {
        $this->db->query('update users set user_name=:name, email=:email, password=:password where id=:id');
        //привязка параметров
        $this->db->bind('name', $data['name']);
        $this->db->bind('email', $data['email']);
        $this->db->bind('password', $data['password']);
        $this->db->bind('id', $data['id']);
    }
    else {
        $this->db->query('update users set user_name=:name, email=:email where id=:id');
        //привязка параметров
        $this->db->bind('name', $data['name']);
        $this->db->bind('email', $data['email']);        
        $this->db->bind('id', $data['id']);
    }
    
    // Выполнение запроса
    if($this->db->execute())
    {
        return true;
    }
    else
    {
        return false;
    }
}

public function removeUser($id) {
    $this->db->query('delete from users where id=:id');
    $this->db->bind('id', $id);
    if($this->db->execute())  {
        return true;
    }
    else  {
        return false;
    }
}

public function addclient($data) {
    $this->db->query('insert into users(user_name, email, password, role) values (:name, :email, :password, :role)');
    //привязка параметров
    $data['password']= password_hash($data['password'], PASSWORD_DEFAULT);
    $this->db->bind('name', $data['name']);
    $this->db->bind('email', $data['email']);
    $this->db->bind('password', $data['password']);
    $this->db->bind('role', $data['role']);
    // Выполнение запроса
    if($this->db->execute())
    {
        $u_id = $this->db->lastId(); 
        $this->db->query("INSERT INTO `clients`(`lname`, `name`, `pat`, `phone`, `user_id`) VALUES (' ', ' ', ' ', ' ', :id)");
        $this->db->bind('id', $u_id);
        $this->db->execute();
        return true;
    }
    else
    {
        return false;
    }
}

}