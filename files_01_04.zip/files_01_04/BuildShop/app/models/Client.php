<?php
class Client{    
    private $db;
    public function __construct(){
        $this->db = new Database;
    }

    public function getClientByUserId($id)     { //  найти клиента по id учетной записи
        $this->db->query('select * from clients where user_id = :id');
        $this->db->bind('id', $id);
        $row = $this->db->single(); 
        return $row;
    }

    public function updateClient($data) { //  изменить клиента
        $this->db->query('update clients set company=:company, lname=:lname, name=:name, pat=:pat, phone=:phone where clientId=:id');
        //привязка параметров
        $this->db->bind('lname', $data['lname']);
        $this->db->bind('name', $data['name']);
        $this->db->bind('pat', $data['pat']);  
        $this->db->bind('phone', $data['phone']);        
        $this->db->bind('id', $data['client']->clientId); 
        if(isset($data['company']))  {
            $this->db->bind('company', $data['company']); 
        }   else {
            $this->db->bind('company', NULL); 
        }
    
        // выполнение
        if($this->db->execute())
        {
            $sql = "";
            if(!empty($data['password'])) {
                $this->db->query('update users set user_name=:user_name, email=:email, password=:password where id=:id');
                //привязка параметров
                $this->db->bind('user_name', $data['user_name']);
                $this->db->bind('email', $data['email']);
                $this->db->bind('password', $data['password']);                       
                $this->db->bind('id',  $_SESSION['user_id']);  
                $this->db->execute();
            }
            else {
                $this->db->query('update users set user_name=:user_name, email=:email where id=:id');
                $this->db->bind('user_name', $data['user_name']);
                $this->db->bind('email', $data['email']);                                      
                $this->db->bind('id',  $_SESSION['user_id']);  
                $this->db->execute();
            }   
            return true;
        }
        else
        {
            return false;
        }
    }

    public function getClients(){ //  получить список клиентов
        $this->db->query("select * from clients");
        $results = $this->db->resultSet();
        return $results;
    } 
    
    public function  addClient($data) //  добавить клиента
    {
     $this->db->query('INSERT INTO `clients`(`lname`, `name`, `patronymic`, `phone`, `mail`) VALUES (:lname, :name, :patronymic, :phone, :mail)');
     //привязка параметров
     $this->db->bind('lname', $data['lname']);
     $this->db->bind('name', $data['name']);
     $this->db->bind('patronymic', $data['patronymic']);  
     $this->db->bind('phone', $data['phone']);    
     $this->db->bind('mail', $data['mail']);      
 
     // выполнение
     if($this->db->execute())
     {
         return true;
     }
     else
     {
         return false;
     }
    }
    public function getClientById($id) //  найти клиента по id
    {
        $this->db->query('select * from clients where clientId = :id');
        $this->db->bind('id', $id);
        $row = $this->db->single(); 
        return $row;
    }

    public function  editClient($data)    { //  изменить клиента
     $this->db->query('update clients set lname = :lname, name = :name, patronymic = :patronymic, phone = :phone, mail = :mail where id = :id');
     $this->db->bind('id', $data['id']);
     $this->db->bind('lname', $data['lname']);
     $this->db->bind('name', $data['name']);
     $this->db->bind('patronymic', $data['patronymic']);  
     $this->db->bind('phone', $data['phone']);    
     $this->db->bind('mail', $data['mail']);
     if($this->db->execute())
     {
         return true;
     }
     else
     {
         return false;
     }
    }

    public function  removeClient($id) //  удалить клиента
    {
     $this->db->query('delete from clients where clientId=:id');
     $this->db->bind('id', $id);
     if($this->db->execute())
     {
         return true;
     }
     else
     {
         return false;
     }
    }  
    
    public function getClientsAndUsers() { //  найти клиентов и их учетные записи
        $this->db->query("SELECT * FROM clients c, users u where c.user_id=u.id");
        $results = $this->db->resultSet();
        return $results;
    }
}