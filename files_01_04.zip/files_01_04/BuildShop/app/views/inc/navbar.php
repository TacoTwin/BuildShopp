<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-3">
<div class="container">
<?php if(isset($_SESSION['user_id'])) 
    {
      if($_SESSION['user_role'] == 'user') {
        ?>
        
  <a class="navbar-brand " href="<?php echo URLROOT; ?>"><?php echo SITENAME;?></a>
  <?php
}}   ?>
<?php if(!isset($_SESSION['user_id'])) 
    {      
        ?>        
  <a class="navbar-brand" href="<?php echo URLROOT; ?>"><?php echo SITENAME;?></a>
  <?php
}   ?> 
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarsExampleDefault">
    <ul class="navbar-nav mr-auto">  
    <?php if(isset($_SESSION['user_id'])) 
    {
      if($_SESSION['user_role'] == 'user') {
      echo '<li class="nav-item">
      <a class="nav-link text-white fw-bold" href="'.URLROOT.'/carts/index">Корзина</a>
    </li> 
    <li class="nav-item">
        <a class="nav-link text-white fw-bold" href="'.URLROOT.'/clients/index">Личный кабинет</a>
      </li> ';
    }
    
    if($_SESSION['user_role'] == 'admin') {
      echo '<li class="nav-item">
      <a class="nav-link text-white fw-bold" href="'.URLROOT.'/admins/index">Панель управления</a>
    </li>';  
    }    
    }   ?> 
    </ul>    
    <ul class="navbar-nav ml-auto">
    <?php if(isset($_SESSION['user_id'])) 
      {
        echo '<li class="nav-item">
      <a class="nav-link text-white fw-bold" href="#">Добро пожаловать, '.$_SESSION['user_name'].'</a>
    </li>';
        echo '<li class="nav-item">
        <a class="nav-link fw-bold text-white" href="'.URLROOT.'/users/logout">Выход</a>
      </li>';      
      }
    else
     {
      echo '<li class="nav-item">
        <a class="nav-link text-white fw-bold" href="'.URLROOT.'/users/login">Авторизация</a>
      </li>
      <li class="nav-item">
      <a class="nav-link text-white fw-bold" href="'.URLROOT.'/users/register">Регистрация</a>
    </li>'; 
      }
    ?></ul>   
  </div>
  </div>
<!-- /.container -->
</nav>