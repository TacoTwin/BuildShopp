<?php require APPROOT.'/views/inc/header.php'; ?>
<div class="row">
<div class="col-md-6 mx-auto">
<div class="card card-body bg-light mt-5">
<h2>Создать аккаунт</h2>
<p>Пожалуйста, заполните форму регистрации</p>
<form action="<?php echo URLROOT; ?>/users/register" method="post">
<div class="form-group">
<label for="name">Имя: <sup>*</sup></label>
<input name="name" type="text" class="form-control form-control-lg <?php echo (!empty($data['name_err'])) ? 'is-invalid' : ''; ?>" value = "<?php echo $data['name']; ?>">
<span class="invalid-feedback"><?php echo $data['name_err']; ?></span> <!-- /.invalid-feedback -->
</div>
<!-- /.form-group -->

<div class="form-group">
<label for="email">Почта: <sup>*</sup></label>
<input name="email" type="email" class="form-control form-control-lg <?php echo (!empty($data['email_err'])) ? 'is-invalid' : ''; ?>" value = "<?php echo $data['email']; ?>">
<span class="invalid-feedback"><?php echo $data['email_err']; ?></span> <!-- /.invalid-feedback -->
</div>
<!-- /.form-group -->

<div class="form-group">
<label for="password">Пароль: <sup>*</sup></label>
<input name="password" type="password" class="form-control form-control-lg <?php echo (!empty($data['password_err'])) ? 'is-invalid' : ''; ?>" value = "<?php echo $data['password']; ?>">
<span class="invalid-feedback"><?php echo $data['password_err']; ?></span> <!-- /.invalid-feedback -->
</div>
<!-- /.form-group -->

<div class="form-group">
<label for="confirm_password">Подтверждение пароля: <sup>*</sup></label>
<input name="confirm_password" type="password" class="form-control form-control-lg <?php echo (!empty($data['confirm_password_err'])) ? 'is-invalid' : ''; ?>" value = "<?php echo $data['confirm_password']; ?>">
<span class="invalid-feedback"><?php echo $data['confirm_password_err']; ?></span> <!-- /.invalid-feedback -->
</div>
<!-- /.form-group -->
<div class="row">
<div class="col">
<input type="submit" value="Регистрация" class="btn btn-success btn-block">
</div>
<!-- /.col -->
<div class="col">
<a href="<?php echo URLROOT; ?>/users/login" class="btn btn-light btn-block">Уже есть аккаунт? Авторизируйтесь.</a> <!-- /.btn btn-light btn-block -->
</div>
<!-- /.col -->
</div>
</form>
</div>
<!-- /.card card-body bg-light mt-5 -->
</div>
<!-- /.col-md-6 -->
</div>
<!-- /.row -->
<?php require APPROOT.'/views/inc/footer.php'; ?>