<?php require APPROOT.'/views/inc/header.php'; ?>
<div class="text-center mt-5 mb-3">
<?php flash('post_message'); ?>
</div>
<!-- /.text-center mt-5 mb-3 -->
<h2 class="text-center mt-5 mb-3">Пользователи</h2>
<div class="row">    
    <div class="offset-md-1 col-md-10 offset-md-1 col-12">    
    <h4 class="text-center mt-5 mb-3">Клиенты</h4>
    <a href="<?php echo URLROOT; ?>/admins/index/" class="btn btn-info">Назад</a>
    <a href="<?php echo URLROOT; ?>/admins/addclient ?>" class="btn btn-success">Добавить клиента</a>    
    <table class="table mt-3">
    <thead class="table-dark">
<tr>
<th>Фамилия</th>
<th>Имя</th>
<th>Отчество</th>
<th>Телефон</th>
<th>Почта</th>
<th>Логин</th>
<th></th>
</tr>
</thead>
<tbody>
<?php foreach($data['clients'] as $client) : ?>     
<tr>
<td><?php echo $client->lname; ?></td>
<td><?php echo $client->name; ?></td>
<td><?php echo $client->pat; ?></td>
<td><?php echo $client->phone; ?></td>
<td><?php echo $client->email; ?></td>
<td><?php echo $client->user_name; ?></td>
<td><a href="<?php echo URLROOT; ?>/admins/delclient/<?php echo $client->clientId; ?>" class="btn btn-danger">Удалить</a></td>
</tr>
<?php endforeach; ?>
</tbody>
    </table>    
    </div>
    <!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->

<div class="row">
    <div class="offset-md-3 col-md-6 offset-md-3 col-12">
    <h4 class="text-center mt-5 mb-3">Администраторы</h4>
    <a href="<?php echo URLROOT; ?>/admins/addadmin ?>" class="btn btn-success">Добавить администратора</a>
    <table class="table mt-3">
    <thead class="table-dark">
<tr>
<th>Имя</th>
<th>Почта</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php foreach($data['admins'] as $admin) : ?>     
<tr>
<td><?php echo $admin->user_name; ?></td>
<td><?php echo $admin->email; ?></td>
<td><a href="<?php echo URLROOT; ?>/admins/editadmin/<?php echo $admin->id; ?>" class="btn btn-warning">Изменить</a></td>
<td><a href="<?php echo URLROOT; ?>/admins/deladmin/<?php echo $admin->id; ?>" class="btn btn-danger">Удалить</a></td>
</tr>
<?php endforeach; ?>
</tbody>
    </table>
    </div>
    <!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->



<?php require APPROOT.'/views/inc/footer.php'; ?>