<?php require APPROOT.'/views/inc/header.php'; ?>
<h2 class="text-center mt-5 mb-3">Категории</h2>
<div class="text-center mt-5 mb-3">
<?php flash('post_message'); ?>
</div>
<!-- /.text-center mt-5 mb-3 -->
<div class="row">    
    <div class="offset-md-3 col-md-6 offset-md-3 col-12">
    <a href="<?php echo URLROOT; ?>/admins/index/" class="btn btn-info">Назад</a>
    <a href="<?php echo URLROOT; ?>/admins/addcategory/; ?>" class="btn btn-success">Добавить</a>
    <table class="table mt-3">
    <thead class="table-dark">
<tr>
<th>Название</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php foreach($data['categories'] as $category) : ?>     
<tr>
<td><?php echo $category->title; ?></td>
<td><a href="<?php echo URLROOT; ?>/admins/editCategory/<?php echo $category->id; ?>" class="btn btn-warning">Изменить</a></td>
<td><a href="<?php echo URLROOT; ?>/admins/deletecategory/<?php echo $category->id; ?>" class="btn btn-danger">Удалить</a></td>
</tr>
<?php endforeach; ?>
</tbody>
    </table>
    </div>
    <!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->
<?php require APPROOT.'/views/inc/footer.php'; ?>