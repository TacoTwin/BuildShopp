<?php require APPROOT.'/views/inc/header.php'; ?>
<h3 class="text-center mt-5 mb-3">Изменение заказа № <?php echo $data['id']; ?> от <?php echo $data['crdate']; ?></h3>
<div class="row">
<div class="col-md-6 mx-auto">
<div class="card card-body bg-light mt-5">
<form action="<?php echo URLROOT; ?>/admins/editorder/<?php echo $data['id'];  ?>" method="post">
<div class="form-group">
<label for="cldate">Дата закрытия: <sup>*</sup></label>
<input name="cldate" required type="date" class="form-control form-control-lg" >

</div>
<!-- /.form-group -->
<div class="form-group">
    <label for="exampleSelect1" class="form-label mt-4">Статус:</label>
      <select name="status" class="form-select" id="exampleSelect1">      
        <option value="Создан">Создан</option> 
        <option value="Отменен">Отменен</option> 
        <option value="В пути">В пути</option> 
        <option value="Сборка">Сборка</option> 
      </select>
    </div>
    <!-- /.form-group --> 
<div class="form-group">
<input type="submit" value="Изменить" class="btn btn-primary btn-block">
</div>
</form>
</div>
<!-- /.card card-body bg-light mt-5 -->
</div>
<!-- /.col-md-6 -->
</div>
<!-- /.row -->


<?php require APPROOT.'/views/inc/footer.php'; ?>