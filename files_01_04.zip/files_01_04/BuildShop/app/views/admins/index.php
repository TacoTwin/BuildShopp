<?php require APPROOT.'/views/inc/header.php'; ?>
<h2 class="text-center mt-5 mb-3">Панель управления</h2>
<div class="row">
    <div class="offset-md-3 col-md-6 offset-md-3 col-12">
    <div class="list-group">
  <a href="#" class="fs-4 list-group-item list-group-item-action active text-center">Выберите действие</a>
  <a href="<?php echo URLROOT.'/admins/categories'; ?>" class="fs-4 list-group-item list-group-item-action">Категории</a>
  <a href="<?php echo URLROOT.'/admins/products'; ?>" class="fs-4 list-group-item list-group-item-action">Товары</a>
  <a href="<?php echo URLROOT.'/admins/clients'; ?>" class="fs-4 list-group-item list-group-item-action">Пользователи</a>
  <a href="<?php echo URLROOT.'/admins/orders'; ?>" class="fs-4 list-group-item list-group-item-action">Заявки</a>
</div>
    </div>
    <!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->
<?php require APPROOT.'/views/inc/footer.php'; ?>