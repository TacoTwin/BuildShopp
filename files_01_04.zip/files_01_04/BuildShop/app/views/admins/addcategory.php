<?php require APPROOT.'/views/inc/header.php'; ?> 

<h2 class="text-center mt-5 mb-3">Новая категория товаров</h2>
<p class="text-center mt-3 mb-2">Для создания новой записи используйте форму ниже:</p>
<div class="row">
    <div class="offset-md-3 col-md-6 offset-md-3 col-12">
    <form action="<?php echo URLROOT; ?>/admins/addcategory" method="post">

<div class="form-group">
<label for="id">Название: <sup>*</sup></label>
<input name="title" type="text" class="form-control form-control-lg <?php echo (!empty($data['title_err'])) ? 'is-invalid' : ''; ?>" value = "<?php echo $data['title']; ?>">
<span class="invalid-feedback"><?php echo $data['title_err']; ?></span> <!-- /.invalid-feedback -->
</div>
<!-- /.form-group --> 
<input type="submit" class="btn btn-info btn-block" value="Создать">
</form>
    </div>
    <!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->
<?php require APPROOT.'/views/inc/footer.php'; ?> 