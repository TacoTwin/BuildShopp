<?php require APPROOT.'/views/inc/header.php'; ?>
<div class="text-center mt-5 mb-3">
<?php flash('post_message'); ?>
</div>
<!-- /.text-center mt-5 mb-3 -->
<h2 class="text-center mt-5 mb-3">Товары</h2>
<div class="row">    
    <div class="offset-md-1 col-md-10 offset-md-1 col-12">
    <a href="<?php echo URLROOT; ?>/admins/index/" class="btn btn-info">Назад</a>
    <a href="<?php echo URLROOT; ?>/admins/addproduct/; ?>" class="btn btn-success">Добавить</a>
    <table class="table mt-3">
    <thead class="table-dark">
<tr>
<th>Фото</th>
<th>Название</th>
<th>Описание</th>
<th>Цена</th>
<th>Категория</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php foreach($data['products'] as $product) : ?>     
<tr>
<td><img class="w-100" src="<?php echo URLROOT.'/public/images/'.$product->image; ?>" alt=""></td>
<td><?php echo $product->title; ?></td>
<td><?php echo $product->description; ?></td>
<td><?php echo $product->price; ?></td>
<td><?php echo $product->cat; ?></td>
<td><a href="<?php echo URLROOT; ?>/admins/editproduct/<?php echo $product->id; ?>" class="btn btn-warning">Изменить</a></td>
<td><a href="<?php echo URLROOT; ?>/admins/deleteproduct/<?php echo $product->id; ?>" class="btn btn-danger">Удалить</a></td>
</tr>
<?php endforeach; ?>
</tbody>
    </table>
    </div>
    <!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->
<?php require APPROOT.'/views/inc/footer.php'; ?>