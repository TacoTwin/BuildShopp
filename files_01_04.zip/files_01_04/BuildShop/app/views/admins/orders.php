<?php require APPROOT.'/views/inc/header.php'; ?>
<div class="text-center mt-5 mb-3">
<?php flash('post_message'); ?>
</div>
<!-- /.text-center mt-5 mb-3 -->
<h2 class="text-center mt-5 mb-3">Заявки</h2>
<div class="row">    
    <div class="offset-md-1 col-md-10 offset-md-1 col-12">
    <a href="<?php echo URLROOT; ?>/admins/index/" class="btn btn-info">Назад</a>
    <table class="table mt-3">
    <thead class="table-dark">
<tr> 
<th>Дата создания</th>
<th>Дата закрытия</th>
<th>Сумма</th>
<th>Статус</th>
<th>Клиент</th>
<th></th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php foreach($data['orders'] as $order) : ?>     
<tr>
<td><?php echo $order->crdate; ?></td>
<td><?php echo $order->cldate; ?></td>
<td><?php echo $order->total; ?></td>
<td><?php echo $order->status; ?></td>
<td><?php echo $order->lname." ".$order->name.", телефон: ".$order->phone; ?></td>
<td><a href="<?php echo URLROOT; ?>/orders/info/<?php echo $order->id; ?>" class="btn btn-info">Товары</a></td>
<td><a href="<?php echo URLROOT; ?>/admins/editorder/<?php echo $order->id; ?>" class="btn btn-warning">Изменить</a></td>
<td><a href="<?php echo URLROOT; ?>/admins/delorder/<?php echo $order->id; ?>" class="btn btn-danger">Удалить</a></td>
</tr>
<?php endforeach; ?>
</tbody>
    </table>
    </div>
    <!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->
<?php require APPROOT.'/views/inc/footer.php'; ?>