<?php require APPROOT.'/views/inc/header.php'; ?>
<h3 class="mt-5 mb-3 text-center">Товары заказа № <?php echo $data['prods'][0]->order_id;  ?></h3>
<div class="row">
    <div class="offset-md-2 col-md-8 offset-md-2 col-12">
    <a href="<?php echo URLROOT; ?>/admins/orders/" class="btn btn-info">Назад</a>
    <table class="table mt-3">
<thead class="table-dark">
<tr>
<th>Название</th>
<th>Количество</th>
<th>Сумма</th>
</tr>
</thead>
<tbody>
<?php $sum=0; foreach($data['prods'] as $prod) : ?>     
<tr>
<td><?php echo $prod->title; ?></td>
<td><?php echo $prod->amount; ?></td>
<td> <?php $sum += $prod->price*$prod->amount; echo $prod->price*$prod->amount; ?></td>
</tr>
<?php endforeach; ?>
</tbody>
<tfoot>
    <tr>
        <td class="fw-bold">Итого: <?php echo $sum; ?></td>
        <td></td>
        <td></td>
    </tr>
</tfoot>
</table>
    </div>
    <!-- /.offset-md-1 col-md-10 offset-md-1 col-12 -->
</div>
<!-- /.row -->


<?php require APPROOT.'/views/inc/footer.php'; ?> 