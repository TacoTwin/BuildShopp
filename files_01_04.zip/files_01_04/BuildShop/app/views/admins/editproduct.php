<?php require APPROOT.'/views/inc/header.php'; ?> 

<h2 class="text-center mt-5 mb-3">Изменение записи о товаре</h2>
<p class="text-center mt-3 mb-2">Для редактирования записи используйте форму ниже:</p>
<div class="row">
<div class="offset-md-3 col-md-6 offset-md-3 col-12">
<form action="<?php echo URLROOT; ?>/admins/editproduct/<?php echo $data['id']; ?>" method="post" enctype="multipart/form-data">
<div class="form-group">
<label for="id">Название: <sup>*</sup></label>
<input name="title" type="text" class="form-control form-control-lg <?php echo (!empty($data['title_err'])) ? 'is-invalid' : ''; ?>" value = "<?php echo $data['title']; ?>">
<span class="invalid-feedback"><?php echo $data['title_err']; ?></span> <!-- /.invalid-feedback -->
</div>
<!-- /.form-group --> 
<div class="form-group">
<label for="id">Краткое описание: <sup>*</sup></label>
<input name="minidescription" type="text" class="form-control form-control-lg <?php echo (!empty($data['minidescription_err'])) ? 'is-invalid' : ''; ?>" value = "<?php echo $data['minidescription']; ?>">
<span class="invalid-feedback"><?php echo $data['minidescription_err']; ?></span> <!-- /.invalid-feedback -->
</div>
<!-- /.form-group --> 
<div class="form-group">
<label for="id">Полное описание: <sup>*</sup></label>
<input name="description" type="text" class="form-control form-control-lg <?php echo (!empty($data['description_err'])) ? 'is-invalid' : ''; ?>" value = "<?php echo $data['description']; ?>">
<span class="invalid-feedback"><?php echo $data['description_err']; ?></span> <!-- /.invalid-feedback -->
</div>
<!-- /.form-group --> 
<div class="form-group">
<label for="id">Цена: <sup>*</sup></label>
<input name="price" type="text" class="form-control form-control-lg <?php echo (!empty($data['price_err'])) ? 'is-invalid' : ''; ?>" value = "<?php echo $data['price']; ?>">
<span class="invalid-feedback"><?php echo $data['price_err']; ?></span> <!-- /.invalid-feedback -->
</div>
<!-- /.form-group --> 
<div class="form-group">
  <label for="formFile" class="form-label mt-4">Изображение:</label>
  <input name="image" class="form-control" type="file" >
  <small>Скопируйте изображение для услуги в каталог public\images\ и выберите его. </small>
</div>
<div class="form-group">
    <label for="exampleSelect1" class="form-label mt-4">Категория:</label>
      <select name="cat" class="form-select" id="exampleSelect1">
      <?php foreach($data['categories'] as $category) : ?>
        <option value="<?php echo $category->id; ?>"><?php echo $category->title; ?></option> 
        <?php endforeach; ?>       
      </select>
    </div>
    <!-- /.form-group -->
<input type="submit" class="btn btn-primary btn-block" value="Изменить">
</form>
</div>
<!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->
<?php require APPROOT.'/views/inc/footer.php'; ?>