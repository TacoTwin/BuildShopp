<?php require APPROOT.'/views/inc/header.php'; ?>

<div class="alert alert-dismissible alert-success text-center mt-5">  
  <strong class="fs-3">Поздравляем!</strong> 
  <p class="fs-5 mt-3">Ваша заявка принята. Примерная дата исполнения: <?php echo $_SESSION['cldate']; ?>. Дождитесь звонка оператора.</p>
</div>

<?php require APPROOT.'/views/inc/footer.php'; ?>