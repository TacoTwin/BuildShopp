<?php require APPROOT.'/views/inc/header.php'; ?>
<h2 class="text-center mt-5 mb-3">Выбранные товары</h2>
<div class="row">
  <div class="offset-md-3 col-md-6 offset-md-3 col-12">
  <table class="table table-hover">
<thead>
    <tr>
        <th>#</th>
        <th>Название</th>
        <th>Количество</th>
        <th>Цена</th>        
        </tr>
</thead>
<tbody>
<?php $N=0; $Sum=0; foreach($data['orders'] as $order) : ?>
    <?php $N++; ?>
    <tr>
    <td><?php echo $N; ?></td>
    <td><?php echo $order->title; ?></td>
    <td><?php echo $order->amount; ?></td>        
    <td><?php $Sum += $order->amount*$order->price;  echo $order->amount*$order->price; ?></td>    
</tr>
    <?php endforeach; ?> 
</tbody>
<tfoot>
    <tr>
        <td></td>
        <td></td>
        <td class="fw-bold text-right">Итого:</td>
    <td class="fw-bold"> <?php echo $Sum; ?></td> 
    </tr>
</tfoot>
</table>
  </div>
  <!-- /.offset-md-6 col-md-6 offset-md-6 col-12 -->
</div>
<!-- /.row -->

<h3 class="text-center mt-5 mb-3">Выбор пункта выдачи:</h3>
<div class="row">
  <div class="offset-md-3 col-md-6 offset-md-3 col-12">
  <form action="<?php echo URLROOT; ?>/orders/add" method="post">
   <input type="hidden" name="clid" value="">
    <div class="form-group">
    <label for="exampleSelect1" class="form-label mt-4">Пункт выдачи:</label>
      <select name="shop" class="form-select" id="exampleSelect1">
      <?php foreach($data['shops'] as $shop) : ?>
        <option value="<?php echo $shop->shopId; ?>"><?php echo $shop->address; ?></option> 
        <?php endforeach; ?>       
      </select>
    </div>
    <!-- /.form-group -->
    <div class="form-group">
    <input  type="checkbox"  id="chkd" />  
    <label class="col-form-label" for="inputDefault">Доставка на объект</label>
    </div>
    <!-- /.form-group -->
    <div   class="form-group input-com hidden-div">
  <label class="col-form-label" for="inputDefault">Адрес</label>
  <input name="address"   class="form-control" type="text"  />
</div> 
    <div class="form-group">
    <input name="mon"  type="checkbox"  id="chk_mon" />  
    <label class="col-form-label" for="inputDefault">Монтаж</label>
    </div>
    <!-- /.form-group -->
    <div class="form-group">
      <label for="exampleTextarea" class="form-label mt-4">Комментарий:</label>
      <textarea name="comment" class="form-control" id="exampleTextarea" rows="3"></textarea>
    </div>
    <div class="form-group">
    <input type="submit" value="Создать" class="btn btn-success btn-block">
    </div>
    <!-- /.form-group -->   
</form>
  </div>
  <!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->

<?php require APPROOT.'/views/inc/footer.php'; ?>