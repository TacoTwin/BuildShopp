<?php require APPROOT.'/views/inc/header.php'; ?>
<?php //flash('post_message'); ?>
<h3 class="mt-5 mb-3 text-center">Личные данные</h3>
<div class="row">
  <div class="offset-md-3 col-md-6 offset-md-3 col-12">
  <form action="<?php echo URLROOT; ?>/clients/change" method="post">
<div class="form-group">
  <label class="col-form-label" for="inputDefault">Фамилия</label>
  <input name="ln" type="text" class="form-control" required value="<?php echo $data['client']->lname; ?>">
</div>
<div class="form-group">
  <label class="col-form-label" for="inputDefault">Имя</label>
  <input name="n" type="text" class="form-control" required value="<?php echo $data['client']->name; ?>">
</div>
<div class="form-group">
  <label class="col-form-label" for="inputDefault">Отчество</label>
  <input name="pat" type="text" class="form-control" value="<?php echo $data['client']->pat; ?>">
</div>
<div class="form-group">
  <label class="col-form-label" for="inputDefault">Телефон</label>
  <input name="ph" type="text" class="form-control" required value="<?php echo $data['client']->phone; ?>">
</div>
<div class="form-group">
  <label class="col-form-label" for="inputDefault">Логин</label>
  <input name="lg" type="text" class="form-control" required value="<?php echo $data['user']->user_name; ?>">
</div>
<div class="form-group">
  <label class="col-form-label" for="inputDefault">Почта</label>
  <input name="email" type="text" class="form-control" required value="<?php echo $data['user']->email; ?>">
</div>
<div class="form-group">
  <label class="col-form-label" for="inputDefault">Пароль</label>
  <input name="pp" type="text" class="form-control">
</div>
<div class="form-group">  
  <input  type="checkbox"  id="chk" />  
  <label class="col-form-label" for="inputDefault">Юридическое лицо</label>
</div>
<div   class="form-group input-com hidden-div">
  <label class="col-form-label" for="inputDefault">Компания</label>
  <input name="comp"   class="form-control" required type="text" value="<?php echo isset($data['client']->company) ? $data['client']->company : ' '; ?>"  />
</div>
<div class="form-group">
    <input type="submit" value="Изменить" class="btn btn-primary btn-block">
    </div>
</form>
  </div>
  <!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->

<h3 class="mt-5 mb-3 text-center">История заказов</h3>

<div class="row">
  <div class="offset-md-1 col-md-10 offset-md-1 col-12">
  <table class="table mt-3">
<thead class="table-dark">
<tr>
<th>Создан</th>
<th>Закрыт</th>
<th>Сумма</th>
<th>Статус</th>
<th>Комментарий</th>
<th></th>
</tr>
</thead>
<tbody>
<?php foreach($data['orders'] as $order) : ?>     
<tr>
<td><?php echo $order->crdate; ?></td>
<td><?php echo $order->cldate; ?></td>
<td> <?php echo $order->total; ?></td>
<td> <?php echo $order->status; ?></td>
<td><?php echo $order->comment; ?></td>
<td><a href="<?php echo URLROOT; ?>/orders/info/<?php echo $order->id; ?>" class="btn btn-warning">Инфо</a></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
  </div>
  <!-- /.offset-md-3 col-md-6 offset-md-3 col-12 -->
</div>
<!-- /.row -->
<?php require APPROOT.'/views/inc/footer.php'; ?> 