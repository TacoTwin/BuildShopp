<?php require APPROOT.'/views/inc/header.php'; ?>

<h2 class="mt-5 mb-3 text-center">Корзина</h2>

<div class="row">
    <div class="offset-md-2 col-md-8 offset-md-2 col-12">
    <table class="table table-hover">
<thead>
    <tr>
        <th>#</th>
        <th>Название</th>
        <th>Количество</th>
        <th>Цена</th>
        <th></th>
        </tr>
</thead>
<tbody>
<?php $N=0; $Sum=0; foreach($data['carts'] as $cart) : ?>
    <?php $N++; ?>
    <tr>
    <td><?php echo $N; ?></td>
    <td><?php echo $cart->title; ?></td>
    <td>
    <a href="<?php echo URLROOT; ?>/carts/minus/<?php echo $cart->cartId; ?>" >
    <img class="cart-button"  class="cart-button" src="<?php echo URLROOT.'/public/images/minus.png'; ?>" alt="">
    </a>
      <span class="fs-5">  <?php echo $cart->amount; ?></span>
    <a href="<?php echo URLROOT; ?>/carts/plus/<?php echo $cart->cartId; ?>" ><img class="cart-button"  class="cart-button" src="<?php echo URLROOT.'/public/images/plus.png'; ?>" alt=""></a>
    </td>        
    <td class="fs-5" ><?php $Sum += $cart->amount*$cart->price;  echo $cart->amount*$cart->price; ?></td>
    <td>
    <a href="<?php echo URLROOT; ?>/carts/del_product/<?php echo $cart->cartId; ?>" class="">    
    <img class="cart-button" src="<?php echo URLROOT.'/public/images/delete.png'; ?>" alt=""></a>
    </td>
</tr>
    <?php endforeach; ?> 
</tbody>
<tfoot>
    <tr>
        <td></td>
        <td></td>
        <td></td>
    <td class="fs-4">Итого: <?php echo $Sum; ?></td>
    </tr>
</tfoot>
</table>
<p>
<a href="<?php echo URLROOT; ?>/orders/index/<?php echo $cart->clid; ?>" class="btn btn-success">Оформить заказ</a>
</p>
    </div>
    <!-- /.offset-md-2 col-md-8 offset-md-2 col-12 -->
</div>
<!-- /.row -->



<?php require APPROOT.'/views/inc/footer.php'; ?>