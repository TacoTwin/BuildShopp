<?php require APPROOT.'/views/inc/header.php'; ?>

<h2 class="text-center mt-5 mb-3"><?php echo $data['product']->title;  ?></h2>
<div class="row">   
    <div class="col-md-5 col-12 p-3">
    <img class="w-100" src="<?php echo URLROOT.'/public/images/'.$data['product']->image; ?>" alt="place">
    </div>
    <!-- /.col-md-4 col-12 -->
    <div class="col-md-7 col-12 p-3">
<p>
<?php echo $data['product']->description;  ?>
<p >Цена: <?php echo $data['product']->price;  ?>р.
<a href="<?php echo URLROOT; ?>/carts/add/<?php echo $data['product']->id; ?>" class="btn btn-primary ml-3">В корзину</a>     
</p>
</p>
</div>
<!-- /.col-md-8 col-12 -->
</div>
<!-- /.row -->
<?php require APPROOT.'/views/inc/footer.php'; ?>