<?php require APPROOT.'/views/inc/header.php'; 
?>
<form action="<?php echo URLROOT; ?>/pages/index" method="POST"  class="mt-5">     
  <div class="input-group mb-3">      
      <input type="text" class="form-control" name="fsearch">
      <button type="submit" name="search" class="btn btn-primary">Найти</button>
  </div>     
</form>
<div class="row">
  <div class="col-md-2 col-12 mb-3">
  <div class="list-group">
  <a href="<?php echo URLROOT; ?>/pages/index" class="list-group-item list-group-item-action active">Категории</a>
  <?php foreach($data['categories'] as $category) : ?>
  <a href="<?php echo URLROOT; ?>/pages/show/<?php echo $category->id; ?>" class="list-group-item list-group-item-action"><?php echo $category->title; ?></a>  
  <?php endforeach; ?> 
</div>
  </div>
  <!-- /.col-md-2 col-12 -->
  <div class="col-md-10 col-12">
  <div class="d-flex flex-wrap justify-content-between">
<?php foreach($data['products'] as $product) : ?>
    <div class="card mb-3 text-center" style="width: 30%;">
  <div class="card-header fs-4"> <a href="<?php echo URLROOT; ?>/products/info/<?php echo $product->id; ?>"><?php echo $product->title; ?></a>  </div>
  <div class="card-body">
    <img class="w-50" style="height:100px;" src="<?php echo URLROOT.'/public/images/'.$product->image; ?>" alt="">
  </div>
  <div class="card-body">    
    <p class="card-text">Цена: <span class="fs-5 badge rounded-pill bg-info"><?php echo $product->price; ?></span></p>
  </div>
  
  <div class="card-body">    
    <p class="card-text"><?php echo $product->minidescription; ?></p>
  </div>
  <div class="card-body">  
  <a href="<?php echo URLROOT; ?>/carts/add/<?php echo $product->id; ?>" class="btn btn-primary">В корзину</a>     
  <a href="<?php echo URLROOT; ?>/products/info/<?php echo $product->id; ?>" class="btn btn-primary">Инфо</a>     
</div>
</div>
    <?php endforeach; ?> 
</div>
<!-- /.row -->
  </div>
  <!-- /.col-md-10 col-12 -->
</div>
<!-- /.row -->




<?php require APPROOT.'/views/inc/footer.php'; ?>