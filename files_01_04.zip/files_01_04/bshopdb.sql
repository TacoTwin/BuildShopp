-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Апр 01 2024 г., 05:44
-- Версия сервера: 8.0.22
-- Версия PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `bshopdb`
--

-- --------------------------------------------------------

--
-- Структура таблицы `carts`
--

CREATE TABLE `carts` (
  `cartId` int UNSIGNED NOT NULL,
  `client_id` int UNSIGNED NOT NULL,
  `product_id` int UNSIGNED NOT NULL,
  `amount` tinyint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `carts`
--

INSERT INTO `carts` (`cartId`, `client_id`, `product_id`, `amount`) VALUES
(3, 2, 5, 1),
(18, 1, 4, 1),
(20, 13, 2, 2),
(21, 13, 3, 1),
(24, 14, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `title`) VALUES
(1, 'Кабели и провод'),
(2, 'Светотехнические изделия'),
(3, 'Аппараты защиты'),
(4, 'Радиаторы и конвекторы');

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--

CREATE TABLE `clients` (
  `clientId` int UNSIGNED NOT NULL,
  `lname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `pat` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `company` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `clients`
--

INSERT INTO `clients` (`clientId`, `lname`, `name`, `pat`, `phone`, `user_id`, `company`) VALUES
(1, 'Антонов', 'Сергей', 'Антонович', '123 455', 1, 'ООО &#34;Старт&#34;'),
(2, 'Еремина', 'Мария', 'Сергеевна', '123 123', 2, NULL),
(13, 'Антонова', 'Алиса', 'Андреевна', '777-543', 24, ''),
(14, 'Иванов', 'Николай', 'Иванович', '999-066', 25, 'ИП Иванов НИ');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int UNSIGNED NOT NULL,
  `crdate` datetime NOT NULL,
  `cldate` datetime DEFAULT NULL,
  `clientid` int UNSIGNED NOT NULL,
  `total` float NOT NULL,
  `comment` text,
  `shop_id` smallint UNSIGNED DEFAULT NULL,
  `status` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `address` varchar(300) DEFAULT NULL,
  `installation` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `crdate`, `cldate`, `clientid`, `total`, `comment`, `shop_id`, `status`, `address`, `installation`) VALUES
(7, '2024-03-17 10:02:11', '2024-03-30 00:00:00', 1, 2430, '', 1, 'Сборка', NULL, NULL),
(8, '2024-03-01 10:08:13', '2024-03-15 00:00:00', 1, 2024, NULL, 2, 'В пути', NULL, NULL),
(10, '2024-02-20 05:03:16', '2024-02-29 00:00:00', 1, 5266, 'Позвонить, если чего-то не будет в наличии', 1, 'В пути', NULL, NULL),
(12, '2024-01-15 10:18:45', '2024-01-28 00:00:00', 1, 5266, '', 1, 'Создан', NULL, NULL),
(14, '2024-03-29 03:41:50', '2024-04-01 00:00:00', 1, 2375, '', 1, 'Создан', NULL, NULL),
(19, '2024-04-01 05:37:24', '2024-04-04 00:00:00', 14, 4750, '', NULL, 'Создан', 'Ленина,24', 1),
(23, '2024-04-01 05:43:25', '2024-04-04 00:00:00', 14, 104, '', 1, 'Создан', NULL, 1),
(24, '2024-04-01 05:43:55', '2024-04-04 00:00:00', 14, 104, '', 2, 'Создан', NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `order_products`
--

CREATE TABLE `order_products` (
  `product_id` int UNSIGNED NOT NULL,
  `order_id` int UNSIGNED NOT NULL,
  `amount` int UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `order_products`
--

INSERT INTO `order_products` (`product_id`, `order_id`, `amount`) VALUES
(1, 23, 1),
(1, 24, 1),
(2, 7, 2),
(3, 8, 1),
(3, 10, 2),
(3, 12, 2),
(4, 14, 1),
(4, 19, 2),
(5, 10, 1),
(5, 12, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` int UNSIGNED NOT NULL,
  `minidescription` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `cat_id` int UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `title`, `price`, `minidescription`, `image`, `description`, `cat_id`) VALUES
(1, 'Кабель силовой, плоский', 104, 'Кабель силовой ВВГнг(А)-LS 3х2.5 плоский', '04.jpg', 'Кабели силовые для стационарной прокладки. Используется для передачи и распределения электрической энергии в стационарных установках на номинальное переменное напряжение0,66 кВ, частотой 50 Гц. Кабель предназначен для прокладки всухих и влажных производственных помещениях, на специальных кабельных эстакадах, в блоках, а также для прокладки на открытом воздухе. Не рекомендуется для прокладки в земле. Кабели выпускаются с изоляцией и оболочкой пониженной пожароопасности и низким уровнем дымовыделения.', 1),
(2, 'Светильник для светодиодных ламп', 946, 'Светильник для светодиодных ламп ДПО-11 2х18 001 2х1200 мм IP40 1240х118х40 мм (Аналог ЛПО 2х36) ЛАЙТ Gauss без ламп', '07.jpg', 'Для ламп Т8 с двусторонним подключением (рекомендуем использовать лампы ТМ GAUSS), Саможимная клеммная колодка, Быстрое и удобное подключение к сети 220В, Возможность сквозной проводки. Простая и быстрая сборка светильника. Не требуется никаких инструментов.', 2),
(3, 'Выключатель автоматический', 445, 'Выключатель автоматический модульный YON MD63 1P 16А C 6kA', '08.jpg', 'Модульный однополюсный автоматический выключатель YON MD63 номиналом 16 A с характеристикой расцепителя \'\'C\'\' и отключающей способностью 6 кА предназначен для применения в электрических цепях на­пряжением до 400 В переменного тока частоты 50 Гц, их защиты при перегрузках и коротких замыканиях, проведения тока в нормальном режиме, оперативного включения и отключения указанных цепей. К выключателю могут присоединяться независимый расцепитель в от­дельном модуле и вспомогательные контакты в отдельном модуле. Независимый расцепитель и вспомогательные контакты заказываются отдельно и устанавливаются на выключатели потребителем по мере необходимости.', 3),
(4, 'Радиатор алюминиевый секционный', 2375, 'Радиатор алюминиевый секционный 500/80/4 боковое подключение', '09.jpg', 'Алюминиевые радиаторы – это прибор, обеспечивающий отопление помещения, изготавливаемый из алюминия. Радиаторы \'\'Oasis\'\' гладкие, легкие, компактные и не требующие окраски. Алюминиевые литые радиаторы \'\'Oasis\'\' производятся самым современным в настоящее время способом - методом \'\'литья под давлением\'\', каждая секция радиатора выливается целиком и к готовой секции приваривается донышко (отстойник). Они обеспечивают быструю передачу тепла воздуху в обогреваемом помещении. Радиатор имеет повышенную коррозийную устойчивость внутренней отделки, что предохраняет прибор от образования ржавчины. В процессе производства прибор проходит современную систему контроля качества на различных этапах, что гарантирует их надежность использования в течение многих лет.', 4),
(5, 'Кабель силовой однопроволочный ТРТС', 72, 'Кабель силовой ППГнг(А)-HF 3х1.5-0.66 однопроволочный ТРТС', '05.jpg', 'Предназначены для передачи и распределения электроэнергии в стационарных установках при номинальном переменном напряжении 0,66 и 1 кВ частотой до 100 Гц, в том числе для эксплуатации в системах АС класса ЗН по классификации НП-001-37. Цена за 1 метр.', 1),
(8, 'Труба гофрированная, легкая серая (25м)', 670, 'Труба гофрированная ПВХ 20 мм с протяжкой легкая серая (25м)', '06.jpg', 'Гибкая гофрированная труба из ПВХ надежно защищает кабель от механических воздействий. Используется для прокладки электрического, компьютерного телефонного кабелей. Труба этого типа прокладывается в стенных штробах, в пустотах фальш-потолков и фальш-стен, в стяжке полов или под фальш-полами. Проволочная протяжка облегчает прокладку кабеля в трубе. Диаметр - 20 мм. Материал – самозатухающий поливинилохлорид (ПВХ). Цвет - серый. Гофрированные трубы из ПВХ легкой серии могут эксплуатироваться при температуре от – 25 °С до + 60 °С. Длина – 25 метров.', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `shops`
--

CREATE TABLE `shops` (
  `shopId` smallint UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `address` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `shops`
--

INSERT INTO `shops` (`shopId`, `title`, `address`) VALUES
(1, 'Пункт №1', 'Ленина, 49'),
(2, 'Пункт №2', 'Матросова, 17'),
(3, 'Пункт №3', 'Лазурная, 22'),
(4, 'Пункт №4', 'Ленина, 203');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int UNSIGNED NOT NULL,
  `user_name` varchar(300) NOT NULL,
  `role` varchar(100) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `user_name`, `role`, `email`, `password`) VALUES
(1, 'Сергей', 'user', 'user1@mail.com', '$2y$10$GA9.DumUSk0KchuCEhTSve/Qy00e4xnY13jjGTlIbc8g71FhyQRKm'),
(2, 'Елена', 'user', 'user2@mail.com', '$2y$10$sS1pSPWpLqMyyc/ia4PxlOD9Aw3rkHZOcTF8WcHtBiea7ZyEAR.kG'),
(11, 'admin', 'admin', 'admin@mail.com', '$2y$10$sS1pSPWpLqMyyc/ia4PxlOD9Aw3rkHZOcTF8WcHtBiea7ZyEAR.kG'),
(24, 'Alissa', 'user', 'ali@ss.aa', '$2y$10$qQXOH7agVLtgMUSgdmH57ucx8o95nDpqEN7BCp6Oa6GcGBSlwqcXq'),
(25, 'Nick', 'user', 'nn@my.rr', '$2y$10$8HDxOYlVlaEcSrhqwJMoteOO9CG0zdUOEL7nGy1U9WOvQmivcuL7C');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`cartId`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`clientId`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shop_id` (`shop_id`),
  ADD KEY `clientid` (`clientid`);

--
-- Индексы таблицы `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`product_id`,`order_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Индексы таблицы `shops`
--
ALTER TABLE `shops`
  ADD PRIMARY KEY (`shopId`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `carts`
--
ALTER TABLE `carts`
  MODIFY `cartId` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `clients`
--
ALTER TABLE `clients`
  MODIFY `clientId` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `shops`
--
ALTER TABLE `shops`
  MODIFY `shopId` smallint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`clientId`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `carts_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`shopId`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`clientid`) REFERENCES `clients` (`clientId`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `order_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
